import cv2

# # imagem = cv2.imread('carro.jpg', 0)
imagem = cv2.imread('ets.webp', 0)

# imagem_suavisada = cv2.GaussianBlur(imagem, (5,5), 0)

# _, limiar = cv2.threshold(imagem_suavisada, 128, 255, cv2.THRESH_BINARY)

# cv2.imshow('Imagem segmentada', limiar)

# cv2.waitKey(0)

# cv2.destroyAllWindows()

bordas = cv2.Canny(imagem, 100, 200)

contornos, hierarquia = cv2.findContours(bordas, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

imagem_com_contornos = cv2.cvtColor(imagem, cv2.COLOR_GRAY2BGR)

cv2.drawContours(imagem_com_contornos, contornos, -1, (0,255,0),2)

cv2.imshow('Imagem segmentada', imagem_com_contornos)

cv2.waitKey(0)

cv2.destroyAllWindows()
